package com.example.marvel;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.widget.ProgressBar;

import com.example.marvel.networking.Http;
import com.example.marvel.networking.Response.characterResponse;
import com.example.marvel.networking.clients.Client;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    @BindView(R.id.toolbar)
    Toolbar toolbar;
    @BindView(R.id.loadingSpinner)
    ProgressBar loadingSpinner;
    @BindView(R.id.comicsRecyclerView)
    RecyclerView comicsRecyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        Http.create(Client.class).getCharacters().enqueue(new Callback<characterResponse>() {
            @Override
            public void onResponse(Call<characterResponse> call, Response<characterResponse> response) {

                Log.i("Print", "success ");

            }

            @Override
            public void onFailure(Call<characterResponse> call, Throwable t) {
                Log.i("Print", "fail");

            }
        });
    }
}
