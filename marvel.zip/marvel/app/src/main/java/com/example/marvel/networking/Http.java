package com.example.marvel.networking;

import com.jakewharton.retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import ae.algorithm.bites.management.common.Configurations;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Http {
    static Retrofit retrofit;

    public static void initialize() {
        String bUrl = "https://gateway.marvel.com:443/v1/public/";
        retrofit = new Retrofit.Builder()
                .baseUrl(bUrl)
                .client(getHeader())
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .build();
    }

    public static <T> T create(Class<T> object) {
        if (retrofit == null)
            initialize();
        return retrofit.create(object);
    }

    public static String PUBLIC_KEY = "ef93aa3ef653a4c7c02410477b85191b";
    private static String PRIVATE_KEY = "6b7ad86b5d52e48fc4d7ab76b2456e759209fe24";

    private static OkHttpClient getHeader() {
        HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
        // set your desired log level
        logging.setLevel(HttpLoggingInterceptor.Level.BODY);


        OkHttpClient okClient = new OkHttpClient.Builder().addInterceptor(logging)
                .addNetworkInterceptor(
                        chain -> {
                            Request request = chain.request();
                            String ts = Long.toString(System.currentTimeMillis() / 1000);

                            HttpUrl url = request.url().newBuilder()
                                    .addQueryParameter("apikey", PUBLIC_KEY)
                                    .addQueryParameter("ts", ts)
                                    .addQueryParameter("hash", md5(ts + PRIVATE_KEY + PRIVATE_KEY))
                                    .build();
                            request = request.newBuilder().url(url).build();
                            return chain.proceed(request);
                        })
                .build();
        return okClient;
    }


    public static String md5(String s) {
        try {
            // Create MD5 Hash
            MessageDigest digest = java.security.MessageDigest.getInstance("MD5");
            digest.update(s.getBytes());
            String hash = new String(Strings.hexEncode(digest.digest()));
            return hash;

        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return "";
    }
}
